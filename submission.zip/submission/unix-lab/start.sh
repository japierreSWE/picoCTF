#!/bin/bash
cd /challenge/html
php -S 0.0.0.0:5555