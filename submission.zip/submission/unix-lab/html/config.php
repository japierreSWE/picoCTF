<?php
$FLAG = "{{flag}}";
$password_file = "passfile.txt";
$salt = '$6$salthere$';
?>