<?php
$FLAG = "{{flag}}";
?>